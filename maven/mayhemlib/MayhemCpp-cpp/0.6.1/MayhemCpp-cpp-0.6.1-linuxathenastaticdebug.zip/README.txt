MayhemCpp 0.6.1 is header-only. GradleRIO requires a static library archive for robot platforms; this one is intentionally empty.
