MayhemCpp 0.3.0 is header-only. GradleRIO requires a static library archive for robot platforms; this one is intentionally empty.
