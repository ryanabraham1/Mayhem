MayhemCpp 0.13.0 is header-only. GradleRIO requires a static library archive for robot platforms; this one is intentionally empty.
